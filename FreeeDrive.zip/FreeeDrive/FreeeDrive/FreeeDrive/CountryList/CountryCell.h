//
//  CountryCell.h
//  Country List
//
//  Created by Pradyumna Doddala on 21/12/13.
//  Copyright (c) 2013 Pradyumna Doddala. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CountryCell : UITableViewCell

@end
