//
//  FieldCell.m
//  FreeeDriveStore
//
//  Created by KL on 3/28/16.
//  Copyright © 2016 Cole Street. All rights reserved.
//

#import "FieldCell.h"

@implementation FieldCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
