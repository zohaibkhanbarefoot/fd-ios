//
//  NotVerifiedViewController.h
//
//
//  Created by KL on 3/9/16.
//  Copyright © 2016 Cole Street. All rights reserved.
//

#import "BaseViewController.h"

@interface NotVerifiedViewController : BaseViewController

@property (strong, nonatomic) NSString *emailString;

@end
