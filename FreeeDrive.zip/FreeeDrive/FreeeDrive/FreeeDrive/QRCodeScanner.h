//
//  MTBViewController.h
//  MTBBarcodeScannerExample
//
//  Created by Mike Buss on 2/8/14.
//
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "FRHyperLabel.h"
@interface QRCodeScanner : BaseViewController


@property (weak, nonatomic) IBOutlet UIButton *nextButton;
@property(nonatomic,weak)IBOutlet UILabel *firstTitleLabel;
@property(nonatomic,weak)IBOutlet UILabel *secTitleLabel;
@property(nonatomic,strong)NSString *phone_number;



@property(nonatomic,weak)IBOutlet UILabel * thirdTitleLabel;
@property (nonatomic,weak)IBOutlet FRHyperLabel *forthTitleLabel;
-(IBAction)btn_link_clicked:(id)sender;

@end
