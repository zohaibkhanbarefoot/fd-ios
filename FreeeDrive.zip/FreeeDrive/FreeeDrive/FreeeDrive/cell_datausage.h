//
//  cell_datausage.h
//  EddystoneScannerSample
//
//  Created by user on 19/01/2017.
//
//

#import <UIKit/UIKit.h>

@interface cell_datausage : UITableViewCell
@property(nonatomic,weak)IBOutlet UILabel *lbl_title;
@end
