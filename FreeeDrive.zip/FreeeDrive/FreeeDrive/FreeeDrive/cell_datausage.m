//
//  cell_datausage.m
//  EddystoneScannerSample
//
//  Created by user on 19/01/2017.
//
//

#import "cell_datausage.h"

@implementation cell_datausage

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
